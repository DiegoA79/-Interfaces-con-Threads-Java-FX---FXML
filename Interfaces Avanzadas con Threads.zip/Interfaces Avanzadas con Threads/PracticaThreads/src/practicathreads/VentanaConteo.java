package practicathreads;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaConteo extends JFrame {

    private JTextField txtClicks;
    private JButton btnContar;
    private JProgressBar progressBar;
    private JButton btnEsperar;
    private int contadorClicks = 0;

    public VentanaConteo() {
        setTitle("Conteo");
        setSize(400, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblTituloClicks = new JLabel("Contar número de clics");
        lblTituloClicks.setBounds(120, 20, 160, 25);
        add(lblTituloClicks);

        txtClicks = new JTextField("1");
        txtClicks.setBounds(50, 50, 285, 30);
        txtClicks.setEditable(false);
        txtClicks.setHorizontalAlignment(JTextField.CENTER);
        add(txtClicks);

        btnContar = new JButton("¡Contar!");
        btnContar.setBounds(140, 95, 120, 30);
        add(btnContar);

        JLabel lblTituloEspera = new JLabel("Esperar 10 segundos");
        lblTituloEspera.setBounds(130, 155, 150, 25);
        add(lblTituloEspera);

        progressBar = new JProgressBar(0, 100);
        progressBar.setBounds(50, 190, 285, 25);
        progressBar.setValue(0);
        progressBar.setStringPainted(true);
        add(progressBar);

        btnEsperar = new JButton("¡Esperar!");
        btnEsperar.setBounds(140, 230, 120, 30);
        add(btnEsperar);

        btnContar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                contadorClicks++;
                txtClicks.setText(String.valueOf(contadorClicks));
            }
        });

        btnEsperar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnEsperar.setEnabled(false);
                progressBar.setValue(0);

                Thread hiloEspera = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            for (int i = 1; i <= 100; i++) {
                                final int progreso = i;
                                
                                SwingUtilities.invokeLater(new Runnable() {
                                    @Override
                                    public void run() {
                                        progressBar.setValue(progreso);
                                    }
                                });
                                
                                Thread.sleep(100);
                            }
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        } finally {
                            SwingUtilities.invokeLater(new Runnable() {
                                @Override
                                public void run() {
                                    btnEsperar.setEnabled(true);
                                }
                            });
                        }
                    }
                });
                hiloEspera.start();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaConteo().setVisible(true);
            }
        });
    }
}