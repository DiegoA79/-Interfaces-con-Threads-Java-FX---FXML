package carerraliebretortuga;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaCarrera extends JFrame {

    private JProgressBar barraLiebre;
    private JProgressBar barraTortuga;
    private JLabel lblEstadoLiebre;
    private JLabel lblEstadoTortuga;
    private JButton btnIniciar;

    public VentanaCarrera() {
        setTitle("La Liebre y la Tortuga - Fábulas de Esopo");
        setSize(450, 320);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel lblLiebre = new JLabel("La Liebre:");
        lblLiebre.setBounds(30, 30, 80, 25);
        add(lblLiebre);

        barraLiebre = new JProgressBar(0, 100);
        barraLiebre.setBounds(110, 30, 280, 25);
        barraLiebre.setStringPainted(true);
        add(barraLiebre);

        lblEstadoLiebre = new JLabel("¡En la línea de salida!");
        lblEstadoLiebre.setBounds(110, 60, 280, 20);
        add(lblEstadoLiebre);

        JLabel lblTortuga = new JLabel("La Tortuga:");
        lblTortuga.setBounds(30, 100, 80, 25);
        add(lblTortuga);

        barraTortuga = new JProgressBar(0, 100);
        barraTortuga.setBounds(110, 100, 280, 25);
        barraTortuga.setStringPainted(true);
        add(barraTortuga);

        lblEstadoTortuga = new JLabel("¡En la línea de salida!");
        lblEstadoTortuga.setBounds(110, 130, 280, 20);
        add(lblEstadoTortuga);

        btnIniciar = new JButton("¡Iniciar Carrera!");
        btnIniciar.setBounds(140, 185, 150, 35);
        add(btnIniciar);

        btnIniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                btnIniciar.setEnabled(false);
                barraLiebre.setValue(0);
                barraTortuga.setValue(0);

                Thread hiloLiebre = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            for (int i = 1; i <= 100; i++) {
                                final int avance = i;
                                
                                if (i == 40) {
                                    SwingUtilities.invokeLater(() -> lblEstadoLiebre.setText("La Liebre: ¡Se durmió!"));
                                    Thread.sleep(6000);
                                } else {
                                    SwingUtilities.invokeLater(() -> lblEstadoLiebre.setText("La Liebre: ¡Está corriendo!"));
                                }

                                SwingUtilities.invokeLater(() -> barraLiebre.setValue(avance));
                                Thread.sleep(70); 
                            }
                            SwingUtilities.invokeLater(() -> lblEstadoLiebre.setText("La Liebre: ¡Llegó a la meta!"));
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

                Thread hiloTortuga = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            for (int i = 1; i <= 100; i++) {
                                final int avance = i;
                                SwingUtilities.invokeLater(() -> {
                                    barraTortuga.setValue(avance);
                                    lblEstadoTortuga.setText("La Tortuga: ¡Está corriendo!");
                                });
                                Thread.sleep(120); 
                            }
                            SwingUtilities.invokeLater(() -> {
                                lblEstadoTortuga.setText("La Tortuga: ¡Llegó a la meta!");
                                btnIniciar.setEnabled(true); 
                            });
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }
                });

                hiloLiebre.start();
                hiloTortuga.start();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new VentanaCarrera().setVisible(true);
            }
        });
    }
}